import React from 'react';

class ZipResult extends React.Component {

  render() {
    return (
      <div>
        <label>{this.props.url}</label>
    
      </div>
    );
  }
}

export default ZipResult;