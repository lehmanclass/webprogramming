import React from 'react';

class GifImage extends React.Component {

  render() {
    return (
      <div>
        <label>{this.props.url}</label>
    
      </div>
    );
  }
}

export default ZipResult;